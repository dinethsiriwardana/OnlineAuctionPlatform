package com.group04.OnlineAuctionPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineAuctionPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
