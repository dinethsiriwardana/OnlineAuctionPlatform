package com.group04.OnlineAuctionPlatform.Factory;

public class ServiceFactory {
}
