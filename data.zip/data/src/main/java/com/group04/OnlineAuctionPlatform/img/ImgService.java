package com.group04.OnlineAuctionPlatform.img;

public class ImgService {
}
